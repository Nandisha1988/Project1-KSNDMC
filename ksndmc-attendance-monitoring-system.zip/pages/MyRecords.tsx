
import React, { useState, useEffect } from 'react';
import { 
  Download, 
  ChevronLeft, 
  ChevronRight, 
  Calendar as CalendarIcon,
  FileSpreadsheet,
  FileText,
  ChevronDown,
  Clock,
  CheckCircle2,
  Loader2
} from 'lucide-react';
import { User, AttendanceRecord } from '../types';
import { dbService } from '../services/db';
import * as XLSX from 'xlsx';
import { jsPDF } from 'jspdf';
import 'jspdf-autotable';

interface MyRecordsProps {
  user: User;
}

const MyRecords: React.FC<MyRecordsProps> = ({ user }) => {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [records, setRecords] = useState<AttendanceRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [showExportMenu, setShowExportMenu] = useState(false);
  const [isExporting, setIsExporting] = useState<string | null>(null);

  useEffect(() => {
    fetchMyData();
  }, [currentDate]);

  const fetchMyData = async () => {
    setLoading(true);
    const start = new Date(currentDate.getFullYear(), currentDate.getMonth(), 1).toISOString().split('T')[0];
    const end = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0).toISOString().split('T')[0];
    
    const allRecords = await dbService.getAttendanceByRange(start, end);
    const myRecords = allRecords.filter(r => r.employeeId === user.employeeId);
    setRecords(myRecords.sort((a, b) => b.date.localeCompare(a.date)));
    setLoading(false);
  };

  const changeMonth = (offset: number) => {
    const next = new Date(currentDate);
    next.setMonth(currentDate.getMonth() + offset);
    setCurrentDate(next);
  };

  const handleExportExcel = () => {
    setIsExporting('excel');
    try {
      const monthYear = currentDate.toLocaleDateString('en-IN', { month: 'long', year: 'numeric' });
      const data = records.map(r => ({
        'Log Date': r.date,
        'Punch In': r.punchIn,
        'Punch Out': r.punchOut || '--:--',
        'Status': r.status,
        'Employee': user.name,
        'Employee ID': user.employeeId,
        'Section': user.section
      }));

      const ws = XLSX.utils.json_to_sheet(data);
      const wb = XLSX.utils.book_new();
      
      // Auto-width logic
      const colWidths = Object.keys(data[0] || {}).map(key => ({
        wch: Math.max(key.length, ...data.map(obj => (obj as any)[key]?.toString().length || 0)) + 4
      }));
      ws['!cols'] = colWidths;

      XLSX.utils.book_append_sheet(wb, ws, "Monthly Attendance");
      XLSX.writeFile(wb, `KSNDMC_Attendance_${user.employeeId}_${monthYear.replace(/\s+/g, '_')}.xlsx`);
    } finally {
      setIsExporting(null);
      setShowExportMenu(false);
    }
  };

  const handleExportPDF = () => {
    setIsExporting('pdf');
    try {
      const monthYear = currentDate.toLocaleDateString('en-IN', { month: 'long', year: 'numeric' });
      const doc = new jsPDF();
      const timestamp = new Date().toLocaleString();
      
      // Branded Header
      doc.setFillColor(15, 23, 42); // slate-900
      doc.rect(0, 0, 210, 45, 'F');
      
      doc.setTextColor(255, 255, 255);
      doc.setFontSize(22);
      doc.setFont('helvetica', 'bold');
      doc.text("KSNDMC", 14, 20);
      
      doc.setFontSize(10);
      doc.setFont('helvetica', 'normal');
      doc.text("Karnataka State Natural Disaster Monitoring Centre", 14, 28);
      doc.text("Official Individual Attendance Statement", 14, 34);
      doc.text(`Generated: ${timestamp}`, 140, 34);

      // Employee Info Section
      doc.setTextColor(15, 23, 42);
      doc.setFontSize(14);
      doc.setFont('helvetica', 'bold');
      doc.text(`Monthly Record: ${monthYear}`, 14, 60);

      doc.setFontSize(10);
      doc.setFont('helvetica', 'normal');
      doc.text(`Staff Name: ${user.name}`, 14, 68);
      doc.text(`Employee ID: ${user.employeeId}`, 14, 74);
      doc.text(`Division/Section: ${user.section}`, 14, 80);

      const tableData = records.map(r => [
        r.date,
        r.punchIn,
        r.punchOut || '--:--',
        r.status
      ]);

      (doc as any).autoTable({
        head: [['Date', 'Punch In', 'Punch Out', 'Current Status']],
        body: tableData,
        startY: 90,
        theme: 'striped',
        headStyles: { fillColor: [16, 185, 129], fontStyle: 'bold' },
        styles: { fontSize: 9, cellPadding: 4 },
        alternateRowStyles: { fillColor: [248, 250, 252] }
      });

      doc.save(`KSNDMC_Attendance_${user.employeeId}_${monthYear.replace(/\s+/g, '_')}.pdf`);
    } finally {
      setIsExporting(null);
      setShowExportMenu(false);
    }
  };

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <h1 className="text-3xl font-black text-slate-800 tracking-tighter">My Attendance History</h1>
          <p className="text-slate-500 font-medium leading-relaxed">Verified departmental records for {user.name}</p>
        </div>
        
        <div className="relative">
          <button 
            onClick={() => setShowExportMenu(!showExportMenu)}
            disabled={records.length === 0 || !!isExporting}
            className="flex items-center gap-3 px-8 py-4 bg-emerald-600 hover:bg-emerald-700 disabled:bg-slate-300 text-white rounded-2xl font-black text-xs uppercase tracking-widest transition-all shadow-xl shadow-emerald-200/50"
          >
            {isExporting ? <Loader2 className="w-5 h-5 animate-spin" /> : <Download className="w-5 h-5" />}
            Export Statement
            <ChevronDown className={`w-4 h-4 transition-transform ${showExportMenu ? 'rotate-180' : ''}`} />
          </button>

          {showExportMenu && (
            <div className="absolute right-0 mt-3 w-56 bg-white border border-slate-100 rounded-2xl shadow-2xl z-50 overflow-hidden animate-in fade-in slide-in-from-top-2">
              <button 
                onClick={handleExportExcel}
                className="w-full px-5 py-4 text-left text-sm font-bold text-slate-600 hover:bg-emerald-50 hover:text-emerald-700 flex items-center gap-4 transition-colors border-b border-slate-50"
              >
                <FileSpreadsheet className="w-5 h-5" /> Excel Spreadsheet
              </button>
              <button 
                onClick={handleExportPDF}
                className="w-full px-5 py-4 text-left text-sm font-bold text-slate-600 hover:bg-rose-50 hover:text-rose-700 flex items-center gap-4 transition-colors"
              >
                <FileText className="w-5 h-5" /> PDF Document
              </button>
            </div>
          )}
        </div>
      </div>

      <div className="bg-white rounded-[2.5rem] border border-slate-200 shadow-sm overflow-hidden transition-all hover:shadow-xl">
        <div className="p-8 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
          <div className="flex items-center gap-6">
            <button 
              onClick={() => changeMonth(-1)} 
              className="p-3 bg-white hover:bg-slate-50 rounded-2xl border border-slate-200 transition-all text-slate-600 shadow-sm"
            >
              <ChevronLeft className="w-6 h-6" />
            </button>
            <div className="flex flex-col items-center min-w-[180px]">
              <h3 className="font-black text-slate-800 text-xl capitalize tracking-tight">
                {currentDate.toLocaleDateString('en-IN', { month: 'long', year: 'numeric' })}
              </h3>
              <span className="text-[10px] font-black uppercase text-slate-400 tracking-widest mt-1">Select Period</span>
            </div>
            <button 
              onClick={() => changeMonth(1)} 
              className="p-3 bg-white hover:bg-slate-50 rounded-2xl border border-slate-200 transition-all text-slate-600 shadow-sm"
            >
              <ChevronRight className="w-6 h-6" />
            </button>
          </div>
          <div className="hidden sm:flex items-center gap-2 px-4 py-2 bg-emerald-50 rounded-full border border-emerald-100">
            <CheckCircle2 className="w-4 h-4 text-emerald-500" />
            <span className="text-xs font-black text-emerald-700 uppercase tracking-widest">{records.length} Logs Found</span>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="bg-white border-b border-slate-100 text-slate-400 text-[10px] font-black uppercase tracking-[0.25em] text-left">
                <th className="px-10 py-6">Reporting Date</th>
                <th className="px-10 py-6 text-center">In Time</th>
                <th className="px-10 py-6 text-center">Out Time</th>
                <th className="px-10 py-6 text-right">Verification</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {loading ? (
                <tr>
                  <td colSpan={4} className="px-10 py-24 text-center">
                    <div className="flex flex-col items-center gap-4">
                      <div className="w-12 h-12 border-4 border-slate-100 border-t-emerald-600 rounded-full animate-spin"></div>
                      <p className="text-slate-400 font-black text-xs uppercase tracking-widest">Accessing Secure Logs...</p>
                    </div>
                  </td>
                </tr>
              ) : records.length > 0 ? (
                records.map((rec) => (
                  <tr key={rec.id} className="hover:bg-slate-50/80 transition-all group">
                    <td className="px-10 py-6">
                      <div className="flex items-center gap-4">
                        <div className="w-10 h-10 bg-slate-100 rounded-xl flex items-center justify-center text-slate-400 group-hover:bg-emerald-100 group-hover:text-emerald-600 transition-colors">
                          <CalendarIcon className="w-5 h-5" />
                        </div>
                        <div>
                          <p className="font-bold text-slate-800">{rec.date}</p>
                          <p className="text-[10px] text-slate-400 font-black uppercase tracking-wider">Official Entry</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-10 py-6 text-center">
                      <div className="inline-flex items-center gap-2 px-3 py-1.5 bg-slate-50 rounded-lg border border-slate-100 font-mono text-sm font-black text-slate-700">
                        <Clock className="w-3.5 h-3.5 text-slate-400" />
                        {rec.punchIn || '--:--'}
                      </div>
                    </td>
                    <td className="px-10 py-6 text-center">
                      <div className="inline-flex items-center gap-2 px-3 py-1.5 bg-slate-50 rounded-lg border border-slate-100 font-mono text-sm font-black text-slate-700">
                        <Clock className="w-3.5 h-3.5 text-slate-400" />
                        {rec.punchOut || '--:--'}
                      </div>
                    </td>
                    <td className="px-10 py-6 text-right">
                      <span className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest ${
                        rec.status === 'PRESENT' ? 'bg-emerald-100 text-emerald-700' : 'bg-rose-100 text-rose-700'
                      }`}>
                        {rec.status === 'PRESENT' && <CheckCircle2 className="w-3 h-3" />}
                        {rec.status}
                      </span>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={4} className="px-10 py-32 text-center">
                    <div className="max-w-xs mx-auto">
                      <div className="w-20 h-20 bg-slate-50 rounded-full flex items-center justify-center mx-auto mb-6">
                        <CalendarIcon className="w-10 h-10 text-slate-200" />
                      </div>
                      <h4 className="font-black text-slate-800 mb-2">No Records Found</h4>
                      <p className="text-sm text-slate-400 font-medium leading-relaxed">
                        We couldn't find any verified attendance entries for this month. Please contact HR if this is an error.
                      </p>
                    </div>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      <div className="flex items-center gap-6 p-8 bg-blue-50/50 rounded-[2rem] border border-blue-100/50">
        <div className="w-12 h-12 bg-blue-100 rounded-2xl flex items-center justify-center text-blue-600 shrink-0 shadow-sm">
          <FileText className="w-6 h-6" />
        </div>
        <div>
          <h4 className="font-black text-slate-800 text-sm uppercase tracking-tight">Audit Ready Statements</h4>
          <p className="text-xs text-slate-500 mt-1 font-medium leading-relaxed italic">
            "Your digital attendance history is maintained for 5 fiscal years. Exported PDFs contain unique document IDs and are admissible for departmental compliance reviews."
          </p>
        </div>
      </div>
    </div>
  );
};

export default MyRecords;
