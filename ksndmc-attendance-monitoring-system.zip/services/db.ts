
import { 
  ref, 
  set, 
  get, 
  update, 
  push, 
  remove, 
  child,
  query,
  orderByChild,
  equalTo
} from 'firebase/database';
import { db, IS_FIREBASE_CONNECTED } from '../lib/firebase';
import { 
  LeaveStatus, 
  EmploymentType, 
  EmployeeDetails, 
  AttendanceRecord, 
  LeaveRequest,
  LeaveBalances,
  GovernmentHoliday
} from '../types';

const DB_KEY = 'ksndmc_database';

const GOVERNMENT_HOLIDAYS: GovernmentHoliday[] = [
  { date: '2026-01-14', name: 'Makara Sankranti', type: 'FESTIVAL' },
  { date: '2026-01-26', name: 'Republic Day', type: 'NATIONAL' },
  { date: '2026-02-15', name: 'Mahashivratri', type: 'FESTIVAL' },
  { date: '2026-03-19', name: 'Ugadi', type: 'FESTIVAL' },
  { date: '2026-03-20', name: 'Eid-ul-Fitr', type: 'FESTIVAL' },
  { date: '2026-04-14', name: 'Dr. B.R. Ambedkar Jayanti', type: 'STATE' },
  { date: '2026-05-01', name: 'May Day', type: 'STATE' },
  { date: '2026-08-15', name: 'Independence Day', type: 'NATIONAL' },
  { date: '2026-09-14', name: 'Ganesh Chaturthi', type: 'FESTIVAL' },
  { date: '2026-10-02', name: 'Gandhi Jayanti', type: 'NATIONAL' },
  { date: '2026-10-19', name: 'Ayudha Puja', type: 'FESTIVAL' },
  { date: '2026-10-20', name: 'Vijayadashami', type: 'FESTIVAL' },
  { date: '2026-11-01', name: 'Kannada Rajyotsava', type: 'STATE' },
  { date: '2026-11-08', name: 'Naraka Chaturdashi', type: 'FESTIVAL' },
  { date: '2026-11-09', name: 'Balipadyami Deepavali', type: 'FESTIVAL' },
  { date: '2026-12-25', name: 'Christmas', type: 'FESTIVAL' },
];

interface DatabaseSchema {
  employees: EmployeeDetails[];
  attendance: AttendanceRecord[];
  leaves: LeaveRequest[];
}

const DEFAULT_BALANCES: LeaveBalances = {
  cl: 12,
  ml: 10,
  el: 30,
  rh: 2,
  co: 0
};

const LEAVE_TYPE_KEY_MAP: Record<string, keyof LeaveBalances> = {
  'Casual Leave (CL)': 'cl',
  'Medical Leave (ML)': 'ml',
  'Earned Leave (EL)': 'el',
  'Restricted Holiday (RH)': 'rh',
  'Compensatory Off (CO)': 'co'
};

const INITIAL_DATA: DatabaseSchema = {
  employees: [
    { 
      id: '1', 
      name: 'Chief Admin', 
      employeeId: 'EMP001', 
      designation: 'Section Head', 
      section: 'HR & IT', 
      location: 'Bengaluru', 
      contact: 'admin@ksndmc.gov.in', 
      dateOfJoining: '2020-01-01', 
      dateOfBirth: '1985-05-20', 
      employmentType: EmploymentType.PERMANENT, 
      isActive: true, 
      username: 'admin', 
      password: 'admin',
      leaveBalances: { ...DEFAULT_BALANCES }
    },
    { 
      id: '2', 
      name: 'Naveen Kumar', 
      employeeId: 'EMP042', 
      designation: 'Technical Assistant', 
      section: 'Seismology', 
      location: 'Bengaluru', 
      contact: 'naveen.k@ksndmc.gov.in', 
      dateOfJoining: '2022-03-15', 
      dateOfBirth: '1992-08-10', 
      employmentType: EmploymentType.PERMANENT, 
      isActive: true, 
      username: 'user', 
      password: 'user',
      leaveBalances: { ...DEFAULT_BALANCES, cl: 8, el: 22 }
    },
  ],
  attendance: [],
  leaves: []
};

class DatabaseService {
  private localData: DatabaseSchema;

  constructor() {
    const saved = localStorage.getItem(DB_KEY);
    this.localData = saved ? JSON.parse(saved) : INITIAL_DATA;
    if (!saved && !IS_FIREBASE_CONNECTED) this.save();
  }

  private save() {
    if (!IS_FIREBASE_CONNECTED) {
      localStorage.setItem(DB_KEY, JSON.stringify(this.localData));
    }
  }

  private calculateDays(start: string, end: string): number {
    const s = new Date(start);
    const e = new Date(end);
    const diffTime = Math.abs(e.getTime() - s.getTime());
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)) + 1;
    return diffDays;
  }

  getHolidays(): GovernmentHoliday[] {
    return GOVERNMENT_HOLIDAYS;
  }

  // --- EMPLOYEE METHODS ---

  async getEmployees(): Promise<EmployeeDetails[]> {
    if (IS_FIREBASE_CONNECTED) {
      const snapshot = await get(ref(db, 'employees'));
      if (snapshot.exists()) {
        const data = snapshot.val();
        return Object.keys(data).map(key => ({ ...data[key], id: key }));
      }
      return [];
    }
    return this.localData.employees;
  }

  async getEmployeeById(employeeId: string): Promise<EmployeeDetails | null> {
    const emps = await this.getEmployees();
    return emps.find(e => e.employeeId === employeeId) || null;
  }

  async addEmployee(employee: Omit<EmployeeDetails, 'id'>) {
    if (IS_FIREBASE_CONNECTED) {
      const newEmpRef = push(ref(db, 'employees'));
      const id = newEmpRef.key!;
      const data = { ...employee, id };
      await set(newEmpRef, data);
      return data;
    } else {
      const newEmp = { ...employee, id: `EMP-${Date.now()}` } as EmployeeDetails;
      this.localData.employees.push(newEmp);
      this.save();
      return newEmp;
    }
  }

  async updateEmployee(id: string, employee: Partial<EmployeeDetails>) {
    if (IS_FIREBASE_CONNECTED) {
      await update(ref(db, `employees/${id}`), employee);
    } else {
      this.localData.employees = this.localData.employees.map(e => e.id === id ? { ...e, ...employee } : e);
      this.save();
    }
  }

  async deleteEmployee(id: string) {
    if (IS_FIREBASE_CONNECTED) {
      await remove(ref(db, `employees/${id}`));
    } else {
      this.localData.employees = this.localData.employees.filter(e => e.id !== id);
      this.save();
    }
  }

  // --- ATTENDANCE METHODS ---

  async getAttendance(date?: string): Promise<AttendanceRecord[]> {
    if (IS_FIREBASE_CONNECTED) {
      const path = date ? `attendance/${date}` : 'attendance';
      const snapshot = await get(ref(db, path));
      if (snapshot.exists()) {
        const data = snapshot.val();
        if (!date) {
          let flatRecords: AttendanceRecord[] = [];
          Object.keys(data).forEach(d => {
            Object.keys(data[d]).forEach(empId => {
              flatRecords.push({ ...data[d][empId], id: `${d}_${empId}` });
            });
          });
          return flatRecords;
        }
        return Object.keys(data).map(empId => ({ ...data[empId], id: `${date}_${empId}` }));
      }
      return [];
    }
    if (!date) return this.localData.attendance;
    return this.localData.attendance.filter(a => a.date === date);
  }

  async getAttendanceByRange(startDate: string, endDate: string): Promise<AttendanceRecord[]> {
    if (IS_FIREBASE_CONNECTED) {
      const all = await this.getAttendance();
      return all.filter(a => a.date >= startDate && a.date <= endDate);
    }
    return this.localData.attendance.filter(a => a.date >= startDate && a.date <= endDate);
  }

  async addManualAttendance(record: Omit<AttendanceRecord, 'id'>) {
    const isHoliday = GOVERNMENT_HOLIDAYS.some(h => h.date === record.date);
    
    if (IS_FIREBASE_CONNECTED) {
      const path = `attendance/${record.date}/${record.employeeId}`;
      await set(ref(db, path), record);

      // Credit Comp-Off if marked as holiday work
      if (isHoliday && record.status === 'HOLIDAY_WORK' && record.isCompOffCredited) {
        const empSnap = await get(ref(db, 'employees'));
        if (empSnap.exists()) {
          const emps = empSnap.val();
          const empKey = Object.keys(emps).find(k => emps[k].employeeId === record.employeeId);
          if (empKey) {
            const currentCo = emps[empKey].leaveBalances?.co || 0;
            await update(ref(db, `employees/${empKey}/leaveBalances`), { co: currentCo + 1 });
          }
        }
      }
      return { ...record, id: `${record.date}_${record.employeeId}` };
    } else {
      const existing = this.localData.attendance.find(a => a.employeeId === record.employeeId && a.date === record.date);
      if (existing) {
        this.localData.attendance = this.localData.attendance.map(a => a.id === existing.id ? { ...a, ...record } : a);
      } else {
        this.localData.attendance.push({ ...record, id: `ATT-${Date.now()}` } as AttendanceRecord);
      }

      if (isHoliday && record.status === 'HOLIDAY_WORK' && record.isCompOffCredited) {
        const emp = this.localData.employees.find(e => e.employeeId === record.employeeId);
        if (emp) {
          emp.leaveBalances.co = (emp.leaveBalances.co || 0) + 1;
        }
      }
      this.save();
      return record;
    }
  }

  // --- LEAVE METHODS ---

  async getLeaves(): Promise<LeaveRequest[]> {
    if (IS_FIREBASE_CONNECTED) {
      const snapshot = await get(ref(db, 'leaves'));
      if (snapshot.exists()) {
        const data = snapshot.val();
        return Object.keys(data).map(key => ({ ...data[key], id: key }));
      }
      return [];
    }
    return this.localData.leaves;
  }
  
  async submitLeave(leave: Omit<LeaveRequest, 'id' | 'status' | 'appliedDate'>) {
    const newLeaveData = {
      ...leave,
      status: LeaveStatus.PENDING,
      appliedDate: new Date().toISOString().split('T')[0]
    };

    if (IS_FIREBASE_CONNECTED) {
      const newLeaveRef = push(ref(db, 'leaves'));
      const id = newLeaveRef.key!;
      const dataWithId = { ...newLeaveData, id };
      await set(newLeaveRef, dataWithId);
      return dataWithId;
    } else {
      const res = { ...newLeaveData, id: `LV-${Date.now()}` } as LeaveRequest;
      this.localData.leaves.push(res);
      this.save();
      return res;
    }
  }

  async updateLeaveStatus(id: string, status: LeaveStatus) {
    if (IS_FIREBASE_CONNECTED) {
      const snapshot = await get(ref(db, `leaves/${id}`));
      if (!snapshot.exists()) return;
      const leave = snapshot.val() as LeaveRequest;
      const previousStatus = leave.status;

      await update(ref(db, `leaves/${id}`), { status });

      if (status === LeaveStatus.APPROVED && previousStatus === LeaveStatus.PENDING) {
        const empSnap = await get(ref(db, `employees`));
        if (empSnap.exists()) {
          const emps = empSnap.val();
          const empKey = Object.keys(emps).find(k => emps[k].employeeId === leave.employeeId);
          if (empKey) {
            const emp = emps[empKey];
            const days = this.calculateDays(leave.startDate, leave.endDate);
            const balanceKey = LEAVE_TYPE_KEY_MAP[leave.leaveType];
            if (balanceKey && emp.leaveBalances) {
              const newBalance = Math.max(0, (emp.leaveBalances[balanceKey] || 0) - days);
              await update(ref(db, `employees/${empKey}/leaveBalances`), { [balanceKey]: newBalance });
            }
          }
        }
      }
    } else {
      const leave = this.localData.leaves.find(l => l.id === id);
      if (!leave) return;

      const previousStatus = leave.status;
      this.localData.leaves = this.localData.leaves.map(l => l.id === id ? { ...l, status } : l);

      if (status === LeaveStatus.APPROVED && previousStatus === LeaveStatus.PENDING) {
        const emp = this.localData.employees.find(e => e.employeeId === leave.employeeId);
        if (emp) {
          const days = this.calculateDays(leave.startDate, leave.endDate);
          const balanceKey = LEAVE_TYPE_KEY_MAP[leave.leaveType];
          if (balanceKey && emp.leaveBalances) {
            emp.leaveBalances[balanceKey] = Math.max(0, emp.leaveBalances[balanceKey] - days);
          }
        }
      }
      this.save();
    }
  }

  // --- STATS ---

  async getDashboardStats() {
    const today = new Date().toISOString().split('T')[0];
    const employees = await this.getEmployees();
    const attendance = await this.getAttendance(today);
    const leaves = await this.getLeaves();

    return {
      totalEmployees: employees.length,
      presentToday: attendance.length,
      onLeave: leaves.filter(l => {
        return l.status === LeaveStatus.APPROVED && today >= l.startDate && today <= l.endDate;
      }).length,
      pendingLeaves: leaves.filter(l => l.status === LeaveStatus.PENDING).length
    };
  }
}

export const dbService = new DatabaseService();
