
import { initializeApp } from 'firebase/app';
import { getDatabase } from 'firebase/database';

// Note: Replace these placeholders with your actual KSNDMC Firebase project credentials
// You can find these in your Firebase Console (Project Settings > General > Your Apps)
const firebaseConfig = {
  apiKey: "AIzaSyDvy9WjaY-ODYTzTp_bfg1te-VnBBuDUx0",
  authDomain: "ksndmc-attendance-4b939.firebaseapp.com",
  databaseURL: "https://ksndmc-attendance-4b939-default-rtdb.asia-southeast1.firebasedatabase.app", // Found in Realtime Database tab
  projectId: "ksndmc-attendance-4b939",
  storageBucket: "ksndmc-attendance-4b939.firebasestorage.app",
  messagingSenderId: "354831860795",
  appId: "G-D9XRB9MHG3"
};

// Check if credentials are valid before initializing
const isConfigValid = firebaseConfig.apiKey !== "AIzaSyDvy9WjaY-ODYTzTp_bfg1te-VnBBuDUx0";

let app;
let db: any;

if (isConfigValid) {
  app = initializeApp(firebaseConfig);
  db = getDatabase(app);
}

export { db };
export const IS_FIREBASE_CONNECTED = isConfigValid;
